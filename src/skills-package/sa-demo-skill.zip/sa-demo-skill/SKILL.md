---
name: sa-demo-skill
description: A demo skill for the Skills Enhancement preview.
---
# sa-demo-skill

Say hello.
